CKEDITOR.plugins.add( 'inlinesave',

{

	init: function( editor )

	{

		editor.addCommand( 'inlinesave',

			{

				exec : function( editor )

				{


					addData();


					
function addData() {

						var data = editor.getData();



						jQuery.ajax({
							type: "POST",



							/*Replace 'dump.php' with the name of the file you wish to use 									to handle the data.

							Data can be retrieved from the variable $_POST											['editable_data'].
*/

							url: "dump.php",

		

					data: { editabledata: data }


						})



						.done(function (data, textStatus, jqXHR) {


							alert("Your content was successfully saved. [" + 							jqXHR.responseText + "]");


						})



						.fail(function (jqXHR, textStatus, errorThrown) {


							alert("Error saving content. [" + jqXHR.responseText + "]");

								});

   
					}
 

				}

			});

		editor.ui.addButton( 'Inlinesave',

		{

			label: 'Save',

			command: 'inlinesave',
			icon: this.path + 'images/inlinesave.png'

		} );

	}

} );