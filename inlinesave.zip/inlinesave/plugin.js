CKEDITOR.plugins.add( 'inlinesave',
{
	init: function( editor )
	{
		editor.addCommand( 'inlinesave',
			{
				exec : function( editor )
				{    
					addData();
					
					function addData() {
						//Gets data from editable html element. Replace "editable" below with the ID of the editable html element.
						var data = CKEDITOR.instances.editable.getData();
						
						//Sends data to a php file via $_POST. Replace "dump.php" below with the name of the php you will be using to retrieve the data.
						//The data can be retrieved from the variable "$_POST['editable_data']", within the php file of course.
						//From there, it is up to you to handle the data appropriately.
						$.post( "dump.php", { editable_data: data} );
						
						//Alerts the user that the content was saved.
						alert("Your content was successfully saved.");
					}
				}
			});
		editor.ui.addButton( 'Inlinesave',
		{
			label: 'Save',
			command: 'inlinesave',
			icon: this.path + 'images/inlinesave.png'
		} );
	}
} );